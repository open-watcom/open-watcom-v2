#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <dos.h>
#include <string.h>
#include <time.h>

#include "paging.h"

char * VPtr;

#define Plot(x,y,c)

void Line(int xd,int yd,int xf,int yf,int Color)
  {
  int i;
  int Dx,Dy,Xi,Yi,Cumul,x,y;

  x=xd;
  y=yd;


  Xi=(xd<xf?+1:-1);
  Yi=(yd<yf?+1:-1);
  Dx=abs(xd-xf);
  Dy=abs(yd-yf);

  y*=640;
  Yi*=640;

  VPtr[x+y]=Color;
  if (Dx>Dy)
    {
    Cumul=Dx >> 1;
    for(i=1;i<=Dx;i++)
      {
      x+=Xi;
      Cumul+=Dy;
      if (Cumul>=Dx)
        {
        Cumul-=Dx;
        y+=Yi;
        }
      VPtr[x+y]=Color;
      }
    }
  else
    {
    Cumul=Dy >> 1;
    for(i=1;i<=Dy;i++)
      {
      y+=Yi;
      Cumul+=Dx;
      if (Cumul>=Dy)
        {
        Cumul-=Dy;
        x+=Xi;
        }
      VPtr[x+y]=Color;
      }
    }
  }


void main(void)
  {
  union REGS Regs;
  int i,k=0;

  // Set to VESA 640x480 256 colors

  Regs.w.ax=0x4f02;
  Regs.w.bx=0x101;
  int386(0x10,&Regs,&Regs);

  // allocate 1Mb Video buffer
  VPtr=(char *)GetLinearVideo(1);
  if (VPtr!=NULL)
    {
    for(;!kbhit();)
      memset(VPtr,rand(),640*480);
    getch();

    // set lines

    while(!kbhit())
      for(i=0;i<480;i++)
        memset(VPtr+i*640,k++,640);

    getch();
    memset(VPtr,0,640*480);  // cls ...
    while(!kbhit())
      Line(rand() % 640,rand() % 480,rand() % 640,rand() % 480,k++);

    // Speedy isn't it ?

    CloseLinearVideo();

    Regs.w.ax=0x03;
    int386(0x10,&Regs,&Regs);

    return;
    }

  Regs.w.ax=0x03;
  int386(0x10,&Regs,&Regs);
  }
