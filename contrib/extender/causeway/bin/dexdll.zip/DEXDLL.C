int main(int reason)
{
	int result;

	if (!reason) {
		printf("DLL startup...\n");	// DLL initialisation.
		/* return zero to let the load continue */
		result=0;
	} else {
		printf("DLL shutdown...\n");	// DLL clean up.
	}
	return(result);
}

extern char *MainToDLLCharStar;
extern int MainToDLLInt;

void __export _cdecl SayHello( char * message)
{
	printf("Received DLL Message: ");
	printf(message);
	CalledByDLL("Nothing much!\n");
	printf("Show main module variables in DLL module:\n");
	printf("%s -- %d\n",MainToDLLCharStar,MainToDLLInt);
}

