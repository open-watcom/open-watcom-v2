extern void _far CWSwap(char*);


void main(void)
{
	CWSwap("mem.exe");
}
